/*!\file teredo64.h
 */
#ifndef _w32_TEREDO64_H
#define _w32_TEREDO64_H

#endif
