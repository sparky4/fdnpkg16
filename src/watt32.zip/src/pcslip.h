/*!\file pcslip.h
 * \deprecated
 */
#ifndef _w32_PCSLIP_H
#define _w32_PCSLIP_H

extern int slip_init (void);

#endif
