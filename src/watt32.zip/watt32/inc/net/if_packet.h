/*!\file net/if_packet.h
 */
#ifndef __LINUX_IF_PACKET_H
#define __LINUX_IF_PACKET_H
#include <net/if_packe.h>   /* Short DOS name */
#endif
