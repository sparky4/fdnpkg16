/*!\file netinet6/ip6.h
 * \note Obsolete. Use netinet/ip6.h.
 */

#error "netinet6/ip6.h is obsolete.  use netinet/ip6.h"
