## Watt-32 old stuff

Various old and "retired" code live here on this attic.
