/*!\file echo.h
 */
#ifndef _w32_ECHO_DISCARD_H
#define _w32_ECHO_DISCARD_H

extern void echo_discard_init (void);
extern void echo_discard_start (void);

#endif
