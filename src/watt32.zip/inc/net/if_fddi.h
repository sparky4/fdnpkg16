/*!\file inc/net/if_fddi.h
 * Compatability header.
 */
#include <netinet/if_fddi.h>
