/*!\file net/if_ether.h
 * Compatability header.
 */
#include <netinet/if_ether.h>

