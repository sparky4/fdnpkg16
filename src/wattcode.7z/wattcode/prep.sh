cd ..
mkdir watt32
cd watt32
unzip -n ../watt32.zip
cd ../wattcode
cp -rp util/* ../watt32/util/
cp -rp src/* ../watt32/src/
