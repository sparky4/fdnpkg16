/*!\file pcrarp.h
 */
#ifndef _w32_PCRARP_H
#define _w32_PCRARP_H

extern WORD _rarptimeout;
extern int  _dorarp (void);

#endif
