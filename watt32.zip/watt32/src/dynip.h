/*!\file dynip.h
 */
#ifndef _w32_DYNIP_H
#define _w32_DYNIP_H

#define dynip_init  NAMESPACE (dynip_init)
#define dynip_exec  NAMESPACE (dynip_exec)

void dynip_init (void);
int  dynip_exec (void);

#endif
