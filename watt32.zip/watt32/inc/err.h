/*!\file err.h
 *
 * Compatibility header (for Net/FreeBSD programs)
 */
#ifndef __SYS_WERRNO_H
#include <sys/werrno.h>
#endif

