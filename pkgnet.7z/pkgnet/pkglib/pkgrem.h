/*
 * This file is part of the SvarDOS project.
 * Copyright (C) Mateusz Viste 2012-2024
 */

#ifndef pkgrem_sentinel
#define pkgrem_sentinel

int pkgrem(const char *pkgname, const char *dosdir);

#endif
