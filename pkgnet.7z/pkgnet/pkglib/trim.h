/*
 * trims any space, tab, cr or lf
 * Copyright (C) 2012-2021 Mateusz Viste
 */

#ifndef trim_sentinel
#define trim_sentinel

void trim(char *str);

#endif
