This directory contains the zlib v1.2.8 library, precompiled with Open Watcom
ver 1.9, for compact and large models.

Compiled with the -DNO_GZIP and -DNOBYFOUR definitions, to save a few
kilobytes of unnecessary bloat.
