/*!\file inc/syslog.h
 * syslog header.
 */
/*
 * POSIX requires (AFAIK) this file in a base-dir
 */
#ifndef __SYS_SYSLOG_H
#include <sys/syslog.h>
#endif
