# Language: swedish / schwedisch
# File ending: sv
# Codepage: 858
# English NLS creator: Mateusz Viez && Victoria Crenshaw (sparky4)
# Translation made by Google Gemini
# This translation was made by Google AI, please help the FreeDOS group
# to improve it.


#### Hj�lp ####

1.0:Detta �r en n�tverkspaketansvarig f�r FreeDOS.
1.1:Anv�ndning: FDNPKG%s �tg�rd [parametrar]
1.2:D�r �tg�rden �r en av f�ljande:
1.3:s�k n�tverksf�rr�d efter paket som inneh�ller 'str'
1.4:samma som 's�k', men skriver �ven ut k�llf�rr�d
1.5:installera paketet 'pkg' (eller lokal zip-fil)
1.6:ta bort paketet 'pkg'
1.7:skriv ut konfigurationen som laddats fr�n cfg-filen
1.8:skriv ut licensen f�r detta program
1.9:FDNPKG%s �r l�nkad mot Watt-32-versionen nedan:
1.10:installera paketet 'pkg' (eller lokal zip-fil) utan k�llor
1.11:installera paketet 'pkg' (eller lokal zip-fil) med k�llor
1.12:visa listan �ver alla installerade paket som inneh�ller 'str'
1.13:s�k efter tillg�ngliga uppdateringar av paket och visa dem
1.14:uppdatera paketet 'pkg' till en nyare version
1.15:uppdatera 'pkg' till senaste version (eller alla paket om inget arg)
1.16:lista alla lokala (installerade) paket som inneh�ller 'str'
1.17:FDNPKG%s �r l�nkad mot WatTCP-versionen nedan:
1.18:lista filer som �gs av paketet 'pkg'
1.19:rensa FDNPKG%s:s lokala cache
1.20:installera om paketet 'pkg' (eller lokal zip-fil)
1.21:FDNPKG%s anv�nder HTTPGET.EXE
1.22:lista alla paket som inneh�ller 'str'
1.23:spara 'pkg' i aktuell version
1.24:�terst�ll 'pkg' f�r uppdateringar
1.25:visa tillg�ngliga paket fr�n repositorier
1.26:samma som 'notinstalled', men skriver �ven ut k�llkodsrepositoriet
1.27:ladda bara ner paketet. installera inte
1.28:ladda ner uppdateringar. installera dem inte


### Allm�nt ####

2.0:%TEMP% inte inst�llt! Du b�r l�ta den peka p� en skrivbar katalog.
2.1:Exempel: SET TEMP=C:\TEMP
2.2:%DOSDIR% inte inst�llt! Du b�r l�ta den peka p� FreeDOS huvudkatalog.
2.3:Exempel: SET DOSDIR=C:\FDOS
2.4:Ogiltigt antal argument. K�r FDNPKG%s utan n�gra parametrar f�r hj�lp.
2.5:Inget f�rr�d �r konfigurerat. Du beh�ver minst ett.
2.6:Du b�r placera minst en post av f�ljande form i din konfigurationsfil:
2.7:REPO www.freedos.org/repo
2.8:Listan �ver konfigurerade FDNPKG%s-f�rr�d f�ljer:
2.9:Uppdaterar %s...
2.10:Nedladdning av f�rr�d misslyckades!
2.11:Ett fel uppstod n�r f�rr�det skulle laddas fr�n tempor�r fil...
2.12:Varning: %TZ% inte inst�llt! tidsst�mplar p� installerade filer kan vara felaktiga.
2.13:Paketdatabas laddad fr�n lokal cache.
2.14:Slut p� minne! (%s)
2.15:Fel: TCP/IP-initiering misslyckades!
2.16:Laddar %s...
2.17:VARNING: Virtuellt minne f�r l�gt. FDNPKG%s kan bete sig op�litligt.
2.18:FEL: Kan inte skriva i katalogen '%s'. Kontrollera din %%TEMP%%-variabel.
2.19:Cache rensad.
2.20:Paketdatabas skapas. V�nligen v�nta t�lmodigt.
2.21:Tryck p� valfri tangent utom Q f�r att forts�tta...
2.22:Fil %s hittades lokalt p� %s.
2.23:Skriva �ver? (1 = NEJ)(2 = JA)


#### Installerar paket ####

3.0:Paket %s �r redan installerat! Ta bort det f�rst om du beh�ver uppgradera.
3.1:Inget paket '%s' hittades i onlinef�rr�den.
3.2:Paketet '%s' �r inte tillg�ngligt i f�rr�den.
3.3:%s �r tillg�ngligt fr�n flera f�rr�d. V�lj vilket du vill anv�nda:
3.4:Ditt val:
3.5:Ogiltigt val!
3.6:Laddar ner paket %s...
3.7:Fel vid nedladdning av paket. Avbrutet.
3.8:Fel: Ogiltigt zip-arkiv! Paket inte installerat.
3.9:Fel: Paketet inneh�ller en fil som redan finns lokalt:
3.10:Fel: Kunde inte skapa %s!
3.11:Paket %s installerat.
3.12:Fel: Paketet inneh�ller inte filen %s! Inget giltigt FreeDOS-paket.
3.13:Fel: Nedladdat paket hade fel CRC. Installation avbruten.
3.14:Fel: Kunde inte �ppna det nedladdade paketet. Installation avbruten.
3.15:Fel: Slut p� minne vid ber�kning av paketets CRC!
3.16:Paket %s installerat (med k�llor, om tillg�ngligt).
3.17:Paket %s installerat (utan k�llor).
3.18:Paket %s �r redan installerat! Du kanske vill anv�nda �tg�rden 'reinstall'.
3.19:Paket %s installerat: %ld filer extraherade, %ld fel.
3.20:Fel: Paketet inneh�ller en krypterad fil:
3.21:Fel: Misslyckades med att �ppna l�nkfilen '%s' f�r l�s�tkomst.
3.22:Fel: Misslyckades med att �ppna l�nkfilen '%s' f�r skriv�tkomst.
3.23:Fel: Paketet inneh�ller ett ogiltigt filnamn:
3.24:Tvinga installation av paket? (1 = NEJ)(2 = JA)(3 = ABORTERA)


#### Tar bort paket ####

4.0:Paket %s �r inte installerat, s� det tas inte bort.
4.1:Fel vid �ppning av lst-fil!
4.2:Dirlist-gr�nsen n�dd. Katalog %s kommer inte att tas bort!
4.3:Slut p� minne! Kunde inte lagra katalog %s!
4.4:tar bort %s
4.5:Paket %s har tagits bort.


#### S�ker paket ####

5.0:Inget paket matchade s�kningen.
5.1:Slut p� minne vid bearbetning av paketbeskrivningar!


#### Hantering av paketdatabas ####

6.0:Fel: Ogiltig indexfil (felaktig sidhuvud)! F�rr�d �verhoppat.
6.1:Fel: Ogiltig indexfil! F�rr�d �verhoppat.
6.2:Fel: Slut p� minne vid laddning av paketdatabas!
6.3:Fel: Kunde inte �ppna datafilen vid '%s'.
6.4:Varning: Kunde inte �ppna db-cachefilen vid %s!
6.5:Meddelande fr�n %s:


#### Laddar konfiguration ####

7.0:Fel: f�rr�d '%s' �r listat tv� g�nger!
7.1:Fel: Kunde inte �ppna konfigurationsfilen '%s'!
7.2:Varning: token utan v�rde p� rad #%d
7.3:Varning: Konfigurationsfil token �verfl�d p� rad #%d
7.4:Varning: token med tomt v�rde p� rad #%d
7.5:Varning: efterf�ljande blanksteg efter v�rde p� rad #%d
7.6:Tappade ett f�rr�d: f�r m�nga konfigurerade (max=%d)
7.8:Varning: Ok�nd token '%s' p� rad #%d
7.9:Varning: Konfigurationsfil v�rde �verfl�d p� rad #%d
7.10:Varning: Ignorerade ett ogiltigt '%s'-v�rde p� rad #%d
7.11:Varning: Ogiltig 'DIR'-direktiv hittades p� rad #%d
7.12:Fel: DIR-s�kv�g f�r l�ng p� rad #%d
7.13:Fel: Hittade obefintlig milj�variabel '%s' p� rad #%d
7.14:Fel: f�rr�d '%s' �r listat tv� g�nger!
7.15:Fel: anpassad katalog '%s' �r inte en giltig absolut s�kv�g!
7.16:Fel: anpassad katalog '%s' �r ett reserverat namn!


#### Packar upp paket ####

8.0:Slut p� minne!
8.1:ok�nd zip-signatur: 0x%08lx
8.2:Fel: Paketet inneh�ller en fil komprimerad med en metod som inte st�ds (%d):
8.3:Fel vid extrahering av '%s' till '%s'!


#### Hantering av den lokala listan �ver installerade paket ####

9.0:Fel: Kunde inte komma �t katalogen %s.
9.1:Fel: Lokalt paket %s hittades inte.


#### Paketuppdateringar ####

10.0:%s (lokal version: %s)
10.1:version %s vid %s
10.2:Ingen uppdatering hittades f�r paketet '%s'.
10.3:En uppdatering av '%s' har hittats. Nedladdning p�g�r...
10.4:%d paket uppdaterade, %d paket misslyckades.
10.5:%d paketuppdatering(ar) hittades.
10.6:Paket %s �r inte installerat.
10.7:S�ker efter uppdateringar...


#### Laddar ner ####

11.0:Laddar ner %s... %ld bytes


#### Sp�rra namnbyte ####

12.0:Fel: Namnbytet av filen %s returnerade ett fel.

