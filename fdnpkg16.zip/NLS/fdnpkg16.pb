# Language: brazilian / brasilianisch
# File ending: pb (formerly ptbr or ptb!)
# Codepage: 860
# English NLS creator: Mateusz Viste && Victoria Crenshaw (sparky4)
# Translation made by Google Gemini
# This translation was made by Google AI, please help the FreeDOS group
# to improve it.

#### Ajuda ####

1.0:Este � um gerenciador de pacotes de rede para FreeDOS.
1.1:Uso: FDNPKG%s a��o [par�metros]
1.2:Onde a a��o � uma das seguintes:
1.3:busca em reposit�rios de rede por pacote contendo 'str'
1.4:o mesmo que 'search', mas tamb�m imprime reposit�rios de origem
1.5:instala o pacote 'pkg' (ou arquivo zip local)
1.6:remove o pacote 'pkg'
1.7:imprime a configura��o carregada do arquivo cfg
1.8:imprime a licen�a deste programa
1.9:FDNPKG%s est� vinculado � vers�o Watt-32 abaixo:
1.10:instala o pacote 'pkg' (ou arquivo zip local) sem fontes
1.11:instala o pacote 'pkg' (ou arquivo zip local) com fontes
1.12:mostra a lista de todos os pacotes instalados contendo 'str'
1.13:verifica atualiza��es dispon�veis de pacotes e as exibe
1.14:atualiza o pacote 'pkg' para uma vers�o mais recente
1.15:atualiza 'pkg' para a �ltima vers�o (ou todos os pacotes se nenhum argumento)
1.16:lista todos os pacotes locais (instalados) contendo 'str'
1.17:FDNPKG%s est� vinculado � vers�o WatTCP abaixo:
1.18:lista os arquivos pertencentes ao pacote 'pkg'
1.19:limpa o cache local do FDNPKG%s
1.20:reinstala o pacote 'pkg' (ou arquivo zip local)
1.21:FDNPKG%s est� usando HTTPGET.EXE
1.22:lista todos os pacotes ou pacotes que cont�m 'str'
1.23:mant�m 'pkg' na vers�o atual
1.24:libera 'pkg' para atualiza��es


### Coisas gerais ####

2.0:%TEMP% n�o definido! Voc� deve fazer com que ele aponte para um diret�rio grav�vel.
2.1:Exemplo: SET TEMP=C:\\TEMP
2.2:%DOSDIR% n�o definido! Voc� deve fazer com que ele aponte para o diret�rio principal do FreeDOS.
2.3:Exemplo: SET DOSDIR=C:\\FDOS
2.4:N�mero inv�lido de argumentos. Execute FDNPKG%s sem nenhum par�metro para obter ajuda.
2.5:Nenhum reposit�rio configurado. Voc� precisa de pelo menos um.
2.6:Voc� deve colocar em seu arquivo de configura��o pelo menos uma entrada desta forma:
2.7:REPO www.freedos.org/repo
2.8:A lista de reposit�rios FDNPKG%s configurados segue:
2.9:Atualizando %s...
2.10:Falha no download do reposit�rio!
2.11:Ocorreu um erro ao tentar carregar o reposit�rio do arquivo tempor�rio...
2.12:Aviso: %TZ% n�o definido! Os carimbos de data/hora nos arquivos instalados podem estar imprecisos.
2.13:Banco de dados de pacotes carregado do cache local.
2.14:Sem mem�ria! (%s)
2.15:Erro: Falha na inicializa��o do TCP/IP!
2.16:Carregando %s...
2.17:AVISO: Mem�ria virtual muito baixa. FDNPKG%s pode se comportar de forma n�o confi�vel.
2.18:ERRO: N�o � poss�vel gravar no diret�rio '%s'. Verifique sua vari�vel %%TEMP%%.
2.19:Cache limpo.
2.20:O banco de dados de pacotes est� sendo criado. Por favor, aguarde.
2.21:Pressione qualquer tecla exceto Q para continuar...

#### Instalando pacote ####

3.0:O pacote %s j� est� instalado! Remova-o primeiro se precisar atualizar.
3.1:Nenhum pacote '%s' encontrado em reposit�rios online.
3.2:O pacote '%s' n�o est� dispon�vel nos reposit�rios.
3.3:%s est� dispon�vel em v�rios reposit�rios. Escolha qual usar:
3.4:Sua escolha:
3.5:Escolha inv�lida!
3.6:Baixando pacote %s...
3.7:Erro ao baixar o pacote. Abortado.
3.8:Erro: Arquivo zip inv�lido! Pacote n�o instalado.
3.9:Erro: O pacote cont�m um arquivo que j� existe localmente:
3.10:Erro: N�o foi poss�vel criar %s!
3.11:Pacote %s instalado.
3.12:Erro: O pacote n�o cont�m o arquivo %s! N�o � um pacote FreeDOS v�lido.
3.13:Erro: O pacote baixado tinha CRC errado. Instala��o abortada.
3.14:Erro: Falha ao abrir o pacote baixado. Instala��o abortada.
3.15:Erro: Sem mem�ria ao calcular o CRC do pacote!
3.16:Pacote %s instalado (com fontes, se dispon�veis).
3.17:Pacote %s instalado (sem fontes).
3.18:O pacote %s j� est� instalado! Voc� pode querer usar a a��o 'update'.
3.19:Pacote %s instalado: %ld arquivos extra�dos, %ld erros.
3.20:Erro: O pacote cont�m um arquivo criptografado:
3.21:Erro: Falha ao abrir o arquivo de link '%s' para acesso de leitura.
3.22:Erro: Falha ao abrir o arquivo de link '%s' para acesso de grava��o.
3.23:Erro: O pacote cont�m um nome de arquivo inv�lido:
3.24:For�ar instala��o do pacote? (1 = N�O)(2 = SIM)

#### Removendo pacote ####

4.0:O pacote %s n�o est� instalado, portanto n�o ser� removido.
4.1:Erro ao abrir o arquivo lst!
4.2:Limite da lista de diret�rios atingido. O diret�rio %s n�o ser� removido!
4.3:Sem mem�ria! N�o foi poss�vel armazenar o diret�rio %s!
4.4:removendo %s
4.5:O pacote %s foi removido.

#### Procurando pacote ####

5.0:Nenhum pacote correspondeu � pesquisa.
5.1:Sem mem�ria ao processar descri��es de pacotes!

#### Manipula��o do banco de dados de pacotes ####

6.0:Erro: Arquivo de �ndice inv�lido (cabe�alho inv�lido)! Reposit�rio ignorado.
6.1:Erro: Arquivo de �ndice inv�lido! Reposit�rio ignorado.
6.2:Erro: Sem mem�ria ao carregar o banco de dados de pacotes!
6.3:Erro: N�o foi poss�vel abrir o arquivo de dados em '%s'.
6.4:Aviso: N�o foi poss�vel abrir o arquivo de cache db em %s!
6.5:Mensagem de %s:

#### Carregando configura��o ####

7.0:Erro: o reposit�rio '%s' est� listado duas vezes!
7.1:Erro: N�o foi poss�vel abrir o arquivo de configura��o '%s'!
7.2:Aviso: token sem valor na linha #%d
7.3:Aviso: estouro de token do arquivo de configura��o na linha #%d
7.4:Aviso: token com valor vazio na linha #%d
7.5:Aviso: espa�os em branco � direita ap�s o valor na linha #%d
7.6:Um reposit�rio foi descartado: muitos configurados (max=%d)
7.8:Aviso: Token desconhecido '%s' na linha #%d
7.9:Aviso: estouro de valor do arquivo de configura��o na linha #%d
7.10:Aviso: Ignorado um valor '%s' ilegal na linha #%d
7.11:Aviso: Diretiva 'DIR' inv�lida encontrada na linha #%d
7.12:Erro: Caminho DIR muito longo na linha #%d
7.13:Erro: Vari�vel de ambiente inexistente '%s' encontrada na linha #%d
7.14:Erro: o reposit�rio '%s' est� listado duas vezes!
7.15:Erro: diret�rio personalizado '%s' n�o � um caminho absoluto v�lido!
7.16:Erro: diret�rio personalizado '%s' � um nome reservado!

#### Descompactando pacote ####

8.0:Sem mem�ria!
8.1:assinatura zip desconhecida: 0x%08lx
8.2:Erro: O pacote cont�m um arquivo compactado com um m�todo n�o suportado (%d):
8.3:Erro ao extrair '%s' para '%s'!

#### Manipulando a lista local de pacotes instalados ####

9.0:Erro: N�o foi poss�vel acessar o diret�rio %s.
9.1:Erro: Pacote local %s n�o encontrado.

#### Atualiza��es de pacotes ####

10.0:%s (vers�o local: %s)
10.1:vers�o %s em %s
10.2:Nenhuma atualiza��o encontrada para o pacote '%s'.
10.3:Uma atualiza��o de '%s' foi encontrada. Atualiza��o em andamento...
10.4:%d pacote(s) atualizado(s), %d pacote(s) falhou(ram).
10.5:%d atualiza��o(�es) de pacote(s) encontrada(s).
10.6:O pacote %s n�o est� instalado.
10.7:Procurando atualiza��es...

#### Baixando ####

11.0:Baixando %s... %ld bytes


#### Renomea��o suspensa ####

12.0:Erro: A renomea��o do arquivo %s retornou um erro.
