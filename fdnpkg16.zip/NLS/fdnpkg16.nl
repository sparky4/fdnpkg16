# Language: dutch / niederl�ndisch
# File ending: nl
# Codepage: 858
# English NLS creator: Mateusz Viste && Victoria Crenshaw (sparky4)
# Translation made by Google Gemini
# This translation was made by Google AI, please help the FreeDOS group
# to improve it.


#### Hulp ####

1.0:Dit is een netwerkpakketbeheerder voor FreeDOS.
1.1:Gebruik: FDNPKG%s actie [parameters]
1.2:Waar actie een van de volgende is:
1.3:zoek in netwerkrepositories naar een pakket dat 'str' bevat
1.4:hetzelfde als 'search', maar drukt ook bronrepository's af
1.5:installeer het pakket 'pkg' (of lokaal zip-bestand)
1.6:verwijder het pakket 'pkg'
1.7:print de configuratie die is geladen uit het cfg-bestand
1.8:print de licentie van dit programma
1.9:FDNPKG%s is gekoppeld aan de Watt-32-versie hieronder:
1.10:installeer het pakket 'pkg' (of lokaal zip-bestand) zonder bronnen
1.11:installeer het pakket 'pkg' (of lokaal zip-bestand) met bronnen
1.12:toon de lijst van alle ge�nstalleerde pakketten die 'str' bevatten
1.13:controleer op beschikbare updates van pakketten en toon deze
1.14:update het 'pkg' pakket naar een nieuwere versie
1.15:update 'pkg' naar de laatste versie (of alle pakketten indien geen argument)
1.16:toon alle lokale (ge�nstalleerde) pakketten die 'str' bevatten
1.17:FDNPKG%s is gekoppeld aan WatTCP-versie hieronder:
1.18:toon bestanden die eigendom zijn van het pakket 'pkg'
1.19:wis de lokale cache van FDNPKG%s
1.20:herinstalleer het pakket 'pkg' (of lokaal zip-bestand)
1.21:FDNPKG%s gebruikt HTTPGET.EXE
1.22:lijst bevat alle pakketten of pakketten die 'str' bevatten
1.23:houd 'pkg' vast op de huidige versie
1.24:geef 'pkg' vrij voor updates
1.25:Toon beschikbare pakketten uit repositories
1.26:Hetzelfde als 'notinstalled', maar print ook de bronrepository
1.27:Download het pakket, installeer het niet
1.28:Download updates, installeer ze niet


### Algemeen ####

2.0:%TEMP% is niet ingesteld! U moet het laten verwijzen naar een beschrijfbare map.
2.1:Voorbeeld: SET TEMP=C:\\TEMP
2.2:%DOSDIR% is niet ingesteld! U moet het laten verwijzen naar de hoofddirectory van FreeDOS.
2.3:Voorbeeld: SET DOSDIR=C:\\FDOS
2.4:Ongeldig aantal argumenten. Voer FDNPKG%s uit zonder parameters voor hulp.
2.5:Er is geen repository geconfigureerd. U heeft er minstens ��n nodig.
2.6:U moet in uw configuratiebestand ten minste ��n vermelding van de volgende vorm plaatsen:
2.7:REPO www.freedos.org/repo
2.8:De lijst met geconfigureerde FDNPKG%s repositories volgt:
2.9:Verversen %s...
2.10:Download van repository mislukt!
2.11:Er is een fout opgetreden bij het laden van de repository uit het tijdelijke bestand...
2.12:Waarschuwing: %TZ% is niet ingesteld! Tijdstempels op ge�nstalleerde bestanden kunnen onnauwkeurig zijn.
2.13:Pakketdatabase geladen uit lokale cache.
2.14:Onvoldoende geheugen! (%s)
2.15:Fout: TCP/IP-initialisatie mislukt!
2.16:Laden %s...
2.17:WAARSCHUWING: Virtueel geheugen te laag. FDNPKG%s kan onbetrouwbaar werken.
2.18:FOUT: Kan niet schrijven in de map '%s'. Controleer uw %%TEMP%% variabele.
2.19:Cache gewist.
2.20:Pakketdatabase wordt aangemaakt. Even geduld alstublieft.
2.21:Druk op een willekeurige toets behalve Q om verder te gaan...
2.22:Bestand %s lokaal gevonden op %s.
2.23:Overschrijven? (1 = NEE)(2 = JA)


#### Pakket installeren ####

3.0:Pakket %s is al ge�nstalleerd! Verwijder het eerst als u wilt upgraden.
3.1:Geen pakket '%s' gevonden in online repositories.
3.2:Pakket '%s' is niet beschikbaar in repositories.
3.3:%s is beschikbaar vanuit meerdere repositories. Kies welke u wilt gebruiken:
3.4:Uw keuze:
3.5:Ongeldige keuze!
3.6:Pakket downloaden %s...
3.7:Fout bij downloaden van pakket. Geannuleerd.
3.8:Fout: Ongeldig zip-archief! Pakket niet ge�nstalleerd.
3.9:Fout: Pakket bevat een bestand dat lokaal al bestaat:
3.10:Fout: Kon %s niet maken!
3.11:Pakket %s ge�nstalleerd.
3.12:Fout: Pakket bevat het %s-bestand niet! Geen geldig FreeDOS-pakket.
3.13:Fout: Gedownload pakket had verkeerde CRC. Installatie afgebroken.
3.14:Fout: Kan gedownload pakket niet openen. Installatie afgebroken.
3.15:Fout: Geheugen ontoereikend tijdens berekenen van CRC van het pakket!
3.16:Pakket %s ge�nstalleerd (met bronnen, indien beschikbaar).
3.17:Pakket %s ge�nstalleerd (zonder bronnen).
3.18:Pakket %s is al ge�nstalleerd! U wilt mogelijk de actie 'update' gebruiken.
3.19:Pakket %s ge�nstalleerd: %ld bestanden uitgepakt, %ld fouten.
3.20:Fout: Pakket bevat een versleuteld bestand:
3.21:Fout: Kan linkbestand '%s' niet openen voor leesrechten.
3.22:Fout: Kan linkbestand '%s' niet openen voor schrijfrechten.
3.23:Fout: Pakket bevat een ongeldige bestandsnaam:
3.24:Pakket gedwongen installeren? (1 = NEE)(2 = JA)


#### Pakket verwijderen ####

4.0:Pakket %s is niet ge�nstalleerd, dus wordt niet verwijderd.
4.1:Fout bij openen lst-bestand!
4.2:Mappenlijstlimiet bereikt. Map %s wordt niet verwijderd!
4.3:Onvoldoende geheugen! Kan map %s niet opslaan!
4.4:verwijderen %s
4.5:Pakket %s is verwijderd.


#### Pakket zoeken ####

5.0:Geen pakket komt overeen met de zoekopdracht.
5.1:Onvoldoende geheugen bij het verwerken van pakketbeschrijvingen!


#### Pakketdatabasebeheer ####

6.0:Fout: Ongeldig indexbestand (verkeerde header)! Repository overgeslagen.
6.1:Fout: Ongeldig indexbestand! Repository overgeslagen.
6.2:Fout: Onvoldoende geheugen bij het laden van de pakketdatabase!
6.3:Fout: Kan het gegevensbestand op '%s' niet openen.
6.4:Waarschuwing: Kan db-cachebestand op %s niet openen!
6.5:Bericht van %s:


#### Configuratie laden ####

7.0:Fout: repository '%s' staat twee keer vermeld!
7.1:Fout: Kan configuratiebestand '%s' niet openen!
7.2:Waarschuwing: token zonder waarde op regel #%d
7.3:Waarschuwing: configuratiebestand token overflow op regel #%d
7.4:Waarschuwing: token met lege waarde op regel #%d
7.5:Waarschuwing: afsluitende witruimte(s) na waarde op regel #%d
7.6:Een repository verwijderd: te veel geconfigureerd (max=%d)
7.8:Waarschuwing: Onbekend token '%s' op regel #%d
7.9:Waarschuwing: Configuratiebestand waarde overflow op regel #%d
7.10:Waarschuwing: Een ongeldige '%s'-waarde op regel #%d genegeerd
7.11:Waarschuwing: Ongeldige 'DIR'-richtlijn gevonden op regel #%d
7.12:Fout: DIR-pad te lang op regel #%d
7.13:Fout: Onbestaande omgevingsvariabele '%s' gevonden op regel #%d
7.14:Fout: repository '%s' staat twee keer vermeld!
7.15:Fout: aangepaste map '%s' is geen geldig absoluut pad!
7.16:Fout: aangepaste map '%s' is een gereserveerde naam!


#### Pakket uitpakken ####

8.0:Onvoldoende geheugen!
8.1:onbekende zip-handtekening: 0x%08lx
8.2:Fout: Pakket bevat een bestand gecomprimeerd met een niet-ondersteunde methode (%d):
8.3:Fout bij uitpakken van '%s' naar '%s'!


#### Lokale lijst van ge�nstalleerde pakketten beheren ####

9.0:Fout: Kan de map %s niet openen.
9.1:Fout: Lokaal pakket %s niet gevonden.


#### Pakketupdates ####

10.0:%s (lokale versie: %s)
10.1:versie %s op %s
10.2:Geen update gevonden voor het pakket '%s'.
10.3:Een update van '%s' is gevonden. Update wordt uitgevoerd...
10.4:%d pakket(ten) bijgewerkt, %d pakket(ten) mislukt.
10.5:%d pakketupdate(s) gevonden.
10.6:Pakket %s is niet ge�nstalleerd.
10.7:Zoeken naar updates...


#### Downloaden ####

11.0:Downloaden %s... %ld bytes


#### Hernoemen gestopt ####

12.0:Fout: Het hernoemen van het bestand %s heeft een fout opgeleverd.

