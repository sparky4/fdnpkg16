#!/bin/bash
screen xxdiff -wB "$1" "$2"
