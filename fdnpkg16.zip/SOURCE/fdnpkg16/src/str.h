/*
 *  This file is part of FDNPKG16
 *  Copyright (C) 2025 sparky4
 */

#ifndef STR_H
#define STR_H

/*
int strcasecmp(const char *s1, const char *s2);
int strncasecmp(const char *s1, const char *s2, size_t n);
*/

#endif
