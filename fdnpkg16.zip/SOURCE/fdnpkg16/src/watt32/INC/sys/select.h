/*!\file sys/select.h
 *
 * Compatibility header.
 */

#include <tcp.h>   /* select_s() */
