/*!\file poll.h
 *
 */
/*
 * POSIX requires (AFAIK) this file in a base-dir
 */
#ifndef __POLL_H
#define __POLL_H

#include <sys/poll.h>

#endif
