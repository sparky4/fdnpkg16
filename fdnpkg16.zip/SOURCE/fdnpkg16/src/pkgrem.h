/*
 * This file is part of the FDNPKG project.
 * Copyright (C) Mateusz Viste 2012-2016. All rights reserved.
 */

#ifndef pkgrem_sentinel
#define pkgrem_sentinel
int pkgrem(char *pkgname, char *dosdir, char *mapdrv);
#endif
