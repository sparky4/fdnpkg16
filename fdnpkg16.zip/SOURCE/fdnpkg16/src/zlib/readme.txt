This directory contains the zlib v1.2.8 library, precompiled in two versions:
  zlib_dj.a   DJGPP v2.05
  zlib_l.lib  Open Watcom v1.9, large memory model

Both versions are compiled with the -DNO_GZIP definition, to save a few
kilobytes of unnecessary code.
