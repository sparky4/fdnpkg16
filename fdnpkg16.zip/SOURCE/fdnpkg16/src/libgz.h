/*
 * This file is part of the FDNPKG16 project.
 * Copyright (C) 2013-2016 Mateusz Viste
 * Copyright (C) 2025 Victoria Crenshaw aka sparky4
 */

#ifndef ungz_h_sentinel
#define ungz_h_sentinel
int ungz(char *srcfile, char *destfile);
#endif
