/*
 * This file is part of the FDNPKG project.
 * Copyright (C) 2013-2016 Mateusz Viste
 */

#ifndef ungz_h_sentinel
#define ungz_h_sentinel
int ungz(char *srcfile, char *destfile);
#endif
