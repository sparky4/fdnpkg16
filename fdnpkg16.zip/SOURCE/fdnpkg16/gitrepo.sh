#!/bin/sh
git clone https://github.com/sezero/watt32.git src/watt32
