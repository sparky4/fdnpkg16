#!/bin/sh
# this script just updates the freedos fdnpkg16 zip package's contents
./pkgunzip.sh
./pkgzip.sh
