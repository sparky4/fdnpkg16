#!/bin/sh
./clean.sh
./build.sh
