#!/bin/sh
rm *.o
rm *.exe
rm *.err
