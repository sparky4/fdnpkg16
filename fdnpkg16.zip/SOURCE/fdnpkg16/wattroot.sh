#!/bin/sh
cd src/watt32/
export WATT_ROOT="$PWD"
echo $WATT_ROOT
#cd ../../
cd src
