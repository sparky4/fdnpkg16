#!/bin/sh
git add .
git commit -a -m "$1"
