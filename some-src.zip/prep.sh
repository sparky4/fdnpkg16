#if not exist src/nul 
mkdir src
	
cp -rp ../crc32.c src/
cp -rp ../fileexst.c src/
cp -rp ../getdelim.c src/
cp -rp ../helpers.c src/
cp -rp ../inf.c src/
cp -rp ../libunzip.c src/
cp -rp ../loadconf.c src/
cp -rp ../lsm.c src/
cp -rp ../parsecmd.c src/
cp -rp ../pkginst.c src/
cp -rp ../pkgrem.c src/
cp -rp ../readenv.c src/
cp -rp ../rtrim.c src/
cp -rp ../showinst.c src/
	
cp -rp fdnpkg16.c src/
cp -rp kprintf0.c src/
